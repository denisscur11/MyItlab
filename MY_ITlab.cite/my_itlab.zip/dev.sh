#!/bin/bash
echo "Starting My ITlab development server..."
python3 run.py 