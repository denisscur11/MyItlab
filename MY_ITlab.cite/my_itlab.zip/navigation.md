# Навігація My ITlab

## Основні сторінки

- [Головна сторінка](http://localhost:5000/)
- [Курси](http://localhost:5000/courses)
- [Про нас](http://localhost:5000/about)
- [Випускники](http://localhost:5000/graduates)
- [Контакти](http://localhost:5000/contact)
- [Часті запитання](http://localhost:5000/faq)
- [Задати питання](http://localhost:5000/ask-question)
- [Записатися на курс](http://localhost:5000/enroll)

## Сторінки курсів

- [Веб розробка](http://localhost:5000/course/web-dev)
- [Python](http://localhost:5000/course/python)
- [Python для дітей](http://localhost:5000/course/python-kids)

## Юридичні сторінки

- [Політика конфіденційності](http://localhost:5000/privacy)
- [Умови використання](http://localhost:5000/terms)
- [Політика щодо файлів cookies](http://localhost:5000/cookies)

## Адміністраторські сторінки

- [Вхід в адмін-панель](http://localhost:5000/admin)
- [Запити на консультацію](http://localhost:5000/admin/requests?key=admin123)
- [Панель керування (прямий доступ)](http://localhost:5000/admin/dashboard/k4k4r4za)

## Інші сторінки

- [Сторінка подяки](http://localhost:5000/thank-you) 