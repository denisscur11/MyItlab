#!/bin/bash
echo "Installing dependencies for My ITlab..."
pip3 install -r requirements.txt
echo "Done!" 